let currentInput = "";
let previousInput = "";
let selectedOperator = null;

const currentDisplay = document.getElementById("display-current");
const historyDisplay = document.getElementById("display-history");

function appendNumber(number) {
    if (number === "." && currentInput.includes(".")) return;
    if (currentInput === "0" && number !== ".") {
        currentInput = number;
    } else {
        currentInput += number;
    }
    updateDisplay();
}

function appendOperator(operator) {
    if (currentInput === "" && previousInput === "") return;
    if (currentInput === "" && previousInput !== "") {
        selectedOperator = operator;
        updateDisplay();
        return;
    }
    if (previousInput !== "") {
        compute();
    }
    selectedOperator = operator;
    previousInput = currentInput;
    currentInput = "";
    updateDisplay();
}

function compute() {
    let result;
    const prev = parseFloat(previousInput);
    const current = parseFloat(currentInput);
    
    // Spelling mistake fixed here perfectly!
    if (isNaN(prev) || isNaN(current)) return;

    switch (selectedOperator) {
        case '+': result = prev + current; break;
        case '-': result = prev - current; break;
        case '*': result = prev * current; break;
        case '/': result = prev / current; break;
        default: return;
    }

    currentInput = result.toString();
    selectedOperator = null;
    previousInput = "";
    updateDisplay();
}

function clearScreen() {
    currentInput = "0";
    previousInput = "";
    selectedOperator = null;
    updateDisplay();
}

function backspace() {
    if (currentInput.length <= 1) {
        currentInput = "0";
    } else {
        currentInput = currentInput.slice(0, -1);
    }
    updateDisplay();
}

function updateDisplay() {
    currentDisplay.innerText = currentInput || "0";
    if (selectedOperator) {
        let opSymbol = selectedOperator === '*' ? '×' : selectedOperator === '/' ? '÷' : selectedOperator;
        historyDisplay.innerText = `${previousInput} ${opSymbol}`;
    } else {
        historyDisplay.innerText = "";
    }
}

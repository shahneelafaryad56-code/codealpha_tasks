let visibleImages = [];
let currentIndex = 0;

// 1. Image Categories logic control (Filter Functionality)
function filterGallery(category, event) {
    const items = document.querySelectorAll('.gallery-item');
    const buttons = document.querySelectorAll('.btn');
    
    buttons.forEach(btn => btn.classList.remove('active'));
    if(event) {
        event.target.classList.add('active');
    }

    items.forEach(item => {
        if (category === 'all' || item.classList.contains(category)) {
            item.style.display = 'block';
        } else {
            item.style.display = 'none';
        }
    });
}

// 2. Lightbox Pop-up Open Logic
function openLightbox(element) {
    // Dynamic array tracking based on active grid layout filter state
    visibleImages = Array.from(document.querySelectorAll('.gallery-grid .gallery-item'))
                         .filter(item => item.style.display !== 'none')
                         .map(item => item.querySelector('img').getAttribute('src'));

    const clickedSrc = element.querySelector('img').getAttribute('src');
    currentIndex = visibleImages.indexOf(clickedSrc);
    
    const lightbox = document.getElementById('lightbox');
    const lightboxImg = document.getElementById('lightbox-img');
    
    lightbox.style.display = 'flex';
    lightboxImg.setAttribute('src', visibleImages[currentIndex]);
}

// 3. Lightbox Pop-up Close Logic
function closeLightbox() {
    document.getElementById('lightbox').style.display = 'none';
}

// 4. Next/Prev Arrow Navigation Logic
function changeImage(direction) {
    if (visibleImages.length === 0) return;
    
    currentIndex += direction;
    
    if (currentIndex >= visibleImages.length) currentIndex = 0;
    if (currentIndex < 0) currentIndex = visibleImages.length - 1;
    
    document.getElementById('lightbox-img').setAttribute('src', visibleImages[currentIndex]);
}

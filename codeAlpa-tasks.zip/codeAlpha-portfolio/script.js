document.addEventListener("DOMContentLoaded", () => {
    const navbar = document.querySelector("nav");
    const resumeButton = document.getElementById("resumeBtn");
    const resumeModal = document.getElementById("resumeModal");
    const closeModalBtn = document.getElementById("closeModalBtn");

    // 1. Dynamic Navbar Scroll Effect
    window.addEventListener("scroll", () => {
        if (window.scrollY > 50) {
            navbar.classList.add("scrolled");
        } else {
            navbar.classList.remove("scrolled");
        }
    });

    // 2. Open Resume Modal (Tested & Working)
    if (resumeButton && resumeModal) {
        resumeButton.addEventListener("click", (e) => {
            e.preventDefault();
            resumeModal.classList.add("active");
            document.body.style.overflow = "hidden";
        });
    }

    // 3. Close Resume Modal
    if (closeModalBtn && resumeModal) {
        closeModalBtn.addEventListener("click", () => {
            resumeModal.classList.remove("active");
            document.body.style.overflow = "auto";
        });

        // Close on clicking outside the modal box
        resumeModal.addEventListener("click", (e) => {
            if (e.target === resumeModal) {
                resumeModal.classList.remove("active");
                document.body.style.overflow = "auto";
            }
        });
    }
});
